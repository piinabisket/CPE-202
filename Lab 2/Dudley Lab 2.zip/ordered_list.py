"""
Functions for Lab 2
Course: CPE 202
Quarter: Spring 2020
Author: Forrest Dudley
"""


class Node:

    def __init__(self, val, next=None, prev=None):
        self.val = val
        self.next = next
        self.prev = prev

    def __repr__(self):
        return f"Node({self.val}, {self.next})"

    def get_val(self):
        return self.val

    def get_next(self):
        return self.next

    def get_prev(self):
        return self.prev

    def set_val(self, newval):
        self.val = newval

    def set_next(self, newnext):
        self.next = newnext

    def set_prev(self, newprev):
        self.prev = newprev


class OrderedList:
    """
    Ordered List object
    Attributes:
        head (Node): head of the list
        tail (Node): tail of the list
        num_items (int): number of items stored in the list
    """

    def __init__(self):
        self.head = head
        self.tail = tail
        self.num_items = num_items

    def __repr__(self):
        return f"{self.head}, {self.tail}, {self.num_items}"

    def __eq__(self, other):
        return (self.head == other.head and
                self.tail == other.tail and
                self.num_items == other.num_items)

    def add(self, item):
        self.num_items += 1
        return self.add_helper(self.head, item)

    def add_helper(self, node, item):
        value = Node(item)
        if node is None:
            self.head = value
            self.tail = value
        elif node.get_val() > item and node.get_prev() == None:
            value.next = node
            node.prev = value
            self.head = value
        elif node.get_val() < item and node.get_next() == None:
            value.prev = node
            node.next = value
            self.tail = value
        elif node.get_val() < item:
            return self.add_helper(node.get_next(), item)
        else:
            prev = node.get_prev()
            value.next = node
            value.prev = prev
            prev.next = value
            node.prev = value

    def remove(self, item):
        self.num_items -= 1
        return self.remove_helper(self.head, item, 0)

    def remove_helper(self, node, item, current):
        if node.get_val() != item and node.next is None:
            raise ValueError
        elif node.get_val() != item:
            return self.remove_helper(node.get_next(), item, current + 1)
        else:
            if node.prev is None and node.next is None:
                self.head = None
                self.tail = None
                return current
            elif node.prev is None:
                self.head = node.next
                node.next.prev = None
                return current
            elif node.next is None:
                self.tail = node.prev
                node.prev.next = None
                return current
            else:
                node.prev.next = node.next
                node.next.prev = node.prev

    def search_forward(self, item):
        return self.search_forward_helper(self.head, item)

    def search_forward_helper(self, node, item):
        """
        helper function for searching an item forward
        Args:
            node (Node): a node
            int (item): a value to search for in the list
        Returns:
            bool: True if found, False otherwise.
        """
        if node is None:
            return False
        if node.val == item:
            return True
        return self.search_forward_helper(node.next, item)

    def search_backward(self, item):
        return self.search_backward_helper(self.tail, item)

    def search_backward_helper(self, node, item):
        """
        a helper function for searching an item forward
        Args:
            node (Node): a node
            int (item): a value to search for in the list
        Returns:
            bool: True if found, False otherwise.
        """
        if node is None:
            return False
        if node.val == item:
            return True
        return self.search_forward_helper(node.prev, item)

    def is_empty(self):
        if self.head is None:
            return True
        else:
            return False

    def size(self):
        value = 0
        cur = self.head
        while cur != None:
            value += 1
            cur = cur.get_next()
        return value

    def index(self, item):
        return self.index_helper(self.head, item)

    def index_helper(self, node, item):
        if node.get_val() == item:
            return 0
        elif node is None:
            raise ValueError
        return 1 + self.index_helper(node.next, item)

    def pop(self, pos):
        if pos is None:
            return self.pop_helper(self.tail, self.size() - 1, self.size() - 1)
        if pos <= (self.size() / 2):
            return self.pop_helper(self.head, pos, 0)
        else:
            return self.pop_helper(self.tail, pos, self.size() - 1)

    def pop_helper(self, node, pos, count):
        if pos <= (self.size() / 2):
            if pos != count and node.next is None:
                ValueError
            elif pos == count:
                value = node.get_val()
                self.remove(value)
                return value
            else:
                self.pop_helper(node.next, pos, count + 1)
        elif pos > (self.size() / 2):
            if pos != count and node.prev is None:
                ValueError
            elif pos == count:
                value = node.get_val()
                self.remove(value)
                return value
            else:
                self.pop_helper(node.prev, pos, count - 1)
